#importing libraries
import pygame
import sys
from math import *

# call the module pygame
pygame.init()

#   Fundamentals of Programming : 15-112 First demo Proejct
#   Pool Game
#   Writtend and edited by : Keivin Isufaj
#   AndrewId: kisufaj
#   Modification history :
#   10/11/2017 : 12:00   15: 30
#   10/11/2017 : 17:00   19: 30
#   11/11/2017 : 10:00   12: 00
#   11/11/2017 : 21:00   24: 00
#   12/11/2017 : 11:00   12: 00
#   12/11/2017 : 17:20   19: 40
#   13/11/2017 : 17:00   20: 00
#   13/11/2017 : 22:00   23: 30
#   14/11/2017 : 16:10   24: 00

friction=0.2 # by default the amount of friction applied
game_won=False # for mainloop purpose
global table_border
table_border=48


table_without_borders=[45,860,50,420] # Defines the borders of the inside part of the table
clock = pygame.time.Clock() # Starts the clock function
bg = pygame.image.load("table.png") # Loads the background
bg = pygame.transform.scale(bg, (900,500)) # Transforms the background into the needed dimensions
screen = pygame.display.set_mode((bg.get_width(),bg.get_height())) # Displays the mainscreen
pygame.mouse.set_visible(0)# Makes mouse invisible



##############################CLASSES#########################
# the balls class has the followinfg properties and functions
# it defines how to change position , when the ball is pocketted
## and where the white ball can be put 
class balls:
    def __init__(self, number,x,y,angle,radius):
        self.number=number  # the number of the ball, white ball=0
        self.x=x #  the center x component
        self.y=y #  the center y component
        self.radius=radius #    radius
        self.angle=angle
        self.velocity=0 #   absolute velocity
        self.sin_x=0 #  sine
        self.cos_x=0 #  cosine
        self.tg_x=0 #   tangent x
        
        
    def show(self):
        global image
        image=pygame.image.load(str(self.number)+".png") #loads the ball as soon as we call the function
        image=pygame.transform.scale(image, (2*self.radius, 2*self.radius))
    def change_position(self):
        self.velocity-=friction
        
        
        if self.velocity<0:
            self.velocity=0
        self.x=self.x+self.velocity*cos(radians(-self.angle)) # horizontal velocity
        self.y=self.y+self.velocity*sin(radians(-self.angle)) # vertical velocity

        if self.x<table_border:
            self.x=table_border
            self.angle=180-self.angle

        if self.x>880-table_border-self.radius:
            self.x=880-table_border-self.radius
            self.angle=180-self.angle

        if self.y<table_border:
            self.y=table_border
            self.angle=360-self.angle

        if self.y> 480 - self.radius - table_border:
            self.y=480 - self.radius - table_border
            self.angle=360-self.angle
        
    def remove(self, balls_in_table):
        balls_in_table.remove(self)
        balls_pocketed.append(self)
    def set_white_ball_position(self,x,y):

            if self.x<table_border+self.radius:
                self.x=table_border+self.radius
            elif self.x>900-2*self.radius:
                self.x=900-2*self.radius
            else : 
                self.x=x
            if self.y<table_border+self.radius:
                self.y=table_border+self.radius

            elif self.y> height - self.radius - table_border:
                self.y=table_border+self.radius
            
            else : 
                self.y=y
        


class Pocket: 
    def __init__ (self,x,y,radius=20):
        self.x=x
        self.y=y
        self.radius=radius
    def ball_in_pocket(self):
        global balls_in_table
        balls_in_table_1= balls_in_table[:]
        for i in range(len(balls_in_table)):
            distance = ((self.x - balls_in_table[i].x)**2 +
                        (self.y - balls_in_table[i].y)**2)**0.5
            
            if distance < self.radius:
                
                if balls_in_table[i] in balls_in_table_1:
                    if balls_in_table[i].number == 8:
                        game_won=True
                    elif balls_in_table[i].number== 0:
                        balls_in_table_1.remove(balls_in_table[i])                           
                    else:
                        balls_in_table_1.remove(balls_in_table[i])
                        
        balls_in_table = balls_in_table_1[:]

class Cue :
    def __init__ (self, x, y,length,color):
        self.x = x
        self.y = y
        self.length=length
        self.color = color
        self.tangent = 0

    def aim_shoot(self,white_ball,magnitude):
            white_ball.angle=self.tangent
            white_ball.velocity= magnitude

    def draw(self, cue_x, cue_y):
            self.x, self.y = pygame.mouse.get_pos()
            self.tangent = (-(degrees(atan2((cue_y - self.y ), (cue_x- self.x)))) ) % 360
            pygame.draw.line(screen, [255,255,255], (cue_x + self.length*cos(radians(-self.tangent)), cue_y + self.length*sin(radians(-self.tangent))), (cue_x, cue_y), 1)
            pygame.draw.line(screen, [0,0,0], (self.x, self.y), (cue_x, cue_y), 6)

# Checks if a collision occurs by checking if it is a tendency
## for the distance to be less than the sum of radii of balls

def is_collision(ball, ball_prime):
    distance = ((ball.x - ball_prime.x)**2 + (ball.y - ball_prime.y)**2)**0.5
    
    if distance < 33:
        return True
    else:
        return False
# algorithm for collision between balls

def collision_between_balls():
   
    for i in range (len(balls_in_table)-1):
        for j in range(i+1,len(balls_in_table)):
            if is_collision(balls_in_table[i],balls_in_table[j]):
                
                if balls_in_table[i].velocity>balls_in_table[j].velocity:
                    fast=balls_in_table[i]
                    slow=balls_in_table[j]
                else :
                    fast=balls_in_table[j]
                    slow=balls_in_table[i]
                if slow.y-fast.y>0:
                    slow.angle=(degrees(atan2((slow.y - fast.y ),
                                                       (slow.x- fast.x))))
                else:
                    slow.angle=-(degrees(atan2((slow.y - fast.y ),
                                                       (slow.x- fast.x))))
                if slow.angle<180 and slow.angle>0:
                    
                    fast.angle=(slow.angle-90)
                    slow.velocity=fast.velocity/2.0+slow.velocity/2.0
                    
                if slow.angle>180 or (slow.angle<0 and slow.angle>-180) :
                    fast.angle=slow.angle+90
                    slow.velocity=fast.velocity/2.0+slow.velocity/2.0
                    
                slow.change_position()
                fast.change_position()


def result():   
    font = pygame.font.SysFont("Algerian", 75)
    if len(balls_in_table) == 0:
        text = font.render("No more balls ! You won !", True, (400, 400, 400))
    if game_won== True :
        text = font.render("8 ball potted...", True, (241, 148, 138))


def restart_game():

    global balls_in_table # the list of all balls that are available
    balls_in_table=[] # starts the list

    # Defining the balls
    

    one=balls(1,638,235,0,15) # --
    two=balls(2,662,260,0,14)

    # appends the balls 

    balls_in_table.append(one)
    balls_in_table.append(two)

def start_game():
    restart_game()
    pockets = [] #list of pockets
    white_ball=balls(0,220,230,0,20)
    balls_in_table.append(white_ball)
    # defining pockets
    p1 = Pocket(44,44)
    p2 = Pocket(420,35)
    p3 = Pocket(820,44)
    p4 = Pocket(820,415)
    p5 = Pocket(420,425)
    p6 = Pocket(44,415)

    # appending pockets
    pockets.append(p1)
    pockets.append(p2)
    pockets.append(p3)
    pockets.append(p4)
    pockets.append(p5)
    pockets.append(p6)


    cueStick=Cue(0,50,200,[255,2555,255]) # Defines the stick
    aim_beginning  = [] # needed to be used in the cue functions
    aim_end = []

    while True: #starting the main loop
        for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_q:
                        pygame.quit()
                        sys.exit()
                    if event.key == pygame.K_r:
                        start_game()
                if event.type == pygame.MOUSEBUTTONDOWN:
                    aim_beginning = [white_ball.x, white_ball.y]
                    x, y = pygame.mouse.get_pos()
                    aim_end = [x ,y]
                    dist = ((aim_beginning[0] - aim_end[0])**2 + (aim_beginning[1] - aim_end[1])**2)**0.5
                    force = dist/10.0
                    if force > 25:
                        force = 25
                    cueStick.aim_shoot(white_ball, force)
        screen.blit(bg, (0,0))

            
        for ball in balls_in_table:
            ball.show()
            screen.blit(image, (ball.x, ball.y))         
            ball.change_position()
        if white_ball not in balls_in_table:
            x,y=pygame.mouse.get_pos()
            white_ball=balls(0,x,y,0,20)
            white_ball.show()
            screen.blit(image, (white_ball.x, white_ball.y))         
            white_ball.change_position()
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    sys.exit()
                    quit()
                if event.type==pygame.MOUSEBUTTONDOWN:
                    balls_in_table.append(white_ball)
                    
        if not (white_ball.velocity > 0):
            cueStick.draw(white_ball.x+white_ball.radius, white_ball.y+white_ball.radius)
        for i in range(6):
            pockets[i].ball_in_pocket()
        collision_between_balls()
        pygame.display.update()
        clock.tick(60)
    result()
start_game()

#importing libraries
import pygame
import sys
from math import *

pygame.init()

#   Fundamentals of Programming : 15-112 First demo Proejct
#   Pool Game
#   Writtend and edited by : Keivin Isufaj
#   AndrewId: kisufaj
#   Modification history :
#   10/11/2017 : 12:00   15: 30
#   10/11/2017 : 17:00   19: 30
#   11/11/2017 : 10:00   12: 00
#   11/11/2017 : 21:00   24: 00
#   12/11/2017 : 11:00   12: 00
#   12/11/2017 : 17:20   19: 40
#   13/11/2017 : 17:00   20: 00
#   13/11/2017 : 22:00   23: 30
#   14/11/2017 : 16:10   24: 00
#   20/11/2017 : 14:20   18: 30
#   21/11/2017 : 10:30   12: 50
#   22/11/2017 : 17:10   22: 30
#   23/11/2017 : 20:50   00: 00
#   24/11/2017 : 23:20   02: 30
#   25/11/2017 : 10:20 -  end



pygame.display.set_caption('POOL K.I')
friction=0.14 # by default the amount of friction applied

global table_border,game_won


pot_music=pygame.mixer.music.load('billiards+2.mp3')
table_border=88
game_won=False # for mainloop purpose
instructions_pic=pygame.image.load('instructions.png')
pygame.transform.scale(instructions_pic,(900,500))
table_without_borders=[45,860,50,420] # Defines the borders of the inside part of the table
clock = pygame.time.Clock() # Starts the clock function
bg = pygame.image.load("table.png") # Loads the background
bg = pygame.transform.scale(bg, (900,500)) # Transforms the background into the needed dimensions
newgame=pygame.image.load('start_game.jpg')
   
pygame.mouse.set_visible(1)# Makes mouse visible



##############################CLASSES#########################
# the balls class has the followinfg properties and functions
# it defines how to change position , when the ball is pocketted
## and where the white ball can be put 
class balls:
    def __init__(self, number,x,y,angle,radius):
        self.number=number  # the number of the ball, white ball=0
        self.x=x #  the center x component
        self.y=y #  the center y component
        self.radius=radius #    radius
        self.angle=angle
        self.velocity=0 #   absolute velocity
        self.sin_x=0 #  sine
        self.image=pygame.image.load(str(self.number)+".png") #loads the ball as soon as we call the function
        self.cos_x=0 #  cosine
        self.tg_x=0 #   tangent x
        
        
    def show(self):

        self.image=pygame.transform.scale(self.image, (2*self.radius, 2*self.radius))
        return self.image
    def change_position(self):
        global screen
        self.angle=self.angle%360
        self.velocity-=friction
        
        
        if self.velocity<0:
            self.velocity=0
        self.x=self.x+self.velocity*cos(radians(-self.angle)) # horizontal velocity
        self.y=self.y+self.velocity*sin(radians(-self.angle)) # vertical velocity

        if self.x<table_border:
            self.x=table_border
            self.angle=180-self.angle

        if self.x>960-table_border-self.radius:
            self.x=960-table_border-self.radius
            self.angle=180-self.angle

        if self.y<table_border:
            self.y=table_border
            self.angle=360-self.angle

        if self.y> 560 - self.radius - table_border:
            self.y=560 - self.radius - table_border
            self.angle=360-self.angle

        screen.blit(self.show(),(self.x,self.y))
        
    def remove(self, balls_in_table):
        balls_in_table.remove(self)
        balls_pocketed.append(self)
    def set_white_ball_position(self,x,y):

            if self.x<table_border+self.radius:
                self.x=table_border+self.radius
            elif self.x>900-2*self.radius:
                self.x=900-2*self.radius
            else : 
                self.x=x
            if self.y<table_border+self.radius:
                self.y=table_border+self.radius

            elif self.y> height - self.radius - table_border:
                self.y=table_border+self.radius
            
            else : 
                self.y=y
        
##########The pocket class###############
#It has defined its location by x and y and the radius
    

class Pocket: 
    def __init__ (self,x,y,radius=20):
        self.x=x
        self.y=y
        self.radius=radius
    #the most important feature of pocket class is ball_in_pocket function
    ##it finds when the balls is put into the pocket
    ### inside function comments
    def ball_in_pocket(self):
        global balls_in_table,solids,stripes,stripes_potted,solids_potted,player1,player2,screen

        balls_in_table_1= balls_in_table[:]
        
        for i in range(len(balls_in_table)):
            distance = ((self.x - balls_in_table[i].x)**2 +
                        (self.y - balls_in_table[i].y)**2)**0.5
            
            if distance < self.radius:
                
                if balls_in_table[i] in balls_in_table_1:
                    if balls_in_table[i].number == 8:
                        balls_in_table_1.remove(balls_in_table[i]) # it removes the ball from the list of balls in table 
                        pygame.mixer.init()
                        pygame.mixer.Channel(2).play(pygame.mixer.Sound('billiards+2.mp3'))
                        if pygame.mouse.get_pressed()[0]:
                            intro_game() # when the mouse is pressed, since it is game over opens mainscreen
                    elif balls_in_table[i].number== 0:
                        balls_in_table_1.remove(balls_in_table[i]) # jsut removes the ball
                        pygame.mixer.init()
                        pygame.mixer.Channel(2).play(pygame.mixer.Sound('billiards+2.mp3'))
                                            
                    else:
                        if balls_in_table[i].number > 0 and balls_in_table[i].number <8:
                            pygame.mixer.init()
                            pygame.mixer.Channel(2).play(pygame.mixer.Sound('billiards+2.mp3'))
                            
                            solids=True #defines the ball as a solid
                            stripes=False# defines the ball as a stripe
                            if balls_in_table[i] in player1_balls:
                                player1=not player1 # doesnt allow the player to change turn 
                                player2= not player2#--
                            if balls_in_table[i] in player2_balls:
                                player2=not player2#same
                                player1= not player1#same
                            solids_potted.append(balls_in_table[i])
                            balls_in_table_1.remove(balls_in_table[i])
                        if balls_in_table[i].number>8:
                            pygame.mixer.init()
                            pygame.mixer.Channel(2).play(pygame.mixer.Sound('billiards+2.mp3'))
                            solids=False# defines the ball as a solid
                            stripes=True#defines the ball as a stripe
                            if balls_in_table[i] in player1_balls:
                                player1=not player1
                                player2=not player2
                            if balls_in_table[i] in player2_balls:
                                player2=not player2
                                player1= not player1
                            stripes_potted.append(balls_in_table[i])
                            balls_in_table_1.remove(balls_in_table[i])

        balls_in_table = balls_in_table_1[:]
###############Cue class##########################
# Has all the definitions of a stick 
class Cue :
    def __init__ (self, x, y,length,color):
        self.x = x
        self.y = y
        self.length=length
        self.color = color
        self.tangent = 0

    def aim_shoot(self,white_ball,magnitude):
            white_ball.angle=self.tangent #defines the angle of white_ball
            white_ball.velocity= magnitude #adds the power of the shot

    def draw(self, cue_x, cue_y): #draws the custick and its trajectory
            self.x, self.y = pygame.mouse.get_pos()
            self.tangent = (-(degrees(atan2((cue_y - self.y ), (cue_x- self.x)))) ) % 360
            pygame.draw.line(screen, [255,255,255], (cue_x + self.length*cos(radians(-self.tangent)), cue_y + self.length*sin(radians(-self.tangent))), (cue_x, cue_y), 1)
            pygame.draw.line(screen, self.color, (self.x, self.y), (cue_x, cue_y), 6)

# Checks if a collision occurs by checking if it is a tendency
## for the distance to be less than the sum of radii of balls

def is_collision(ball, ball_prime):
    distance = ((ball.x - ball_prime.x)**2 + (ball.y - ball_prime.y)**2)**0.5
    
    if distance <ball.radius+ball_prime.radius:
        return True
    else:
        return False
# algorithm for collision between balls

def collision_between_balls():
    global white_ball,player1,player2,foul,game_won
    foul=False

    numofcollisions=0
    for i in range (len(balls_in_table)-1):
        for j in range(i+1,len(balls_in_table)):
            

##################################    FOUL     ######################################

            if is_collision(balls_in_table[i],balls_in_table[j]):

                if balls_in_table[i]==white_ball : 
                    numofcollisions=1
                    if numofcollisions==1 and len(player1_balls)>0 and len(player2_balls)>0:
                        if player1:
                            if ( balls_in_table[j] not in player1_balls ) :
                                foul=True
                        if player2:
                            if (balls_in_table[j] not in player2_balls):
                                foul=True
                if balls_in_table[j]==white_ball:
                    numofcollisions+=1
                    if numofcollisions==1 and len(player1_balls)>0 and len(player2_balls)>0 :
                        if player1:
                            if (balls_in_table[i] not in player1_balls):
                                foul=True
                        if player2:
                            if (balls_in_table[i] not in player2_balls):
                                foul=True
############################    ANGLES     ########################################                               
                if balls_in_table[i].velocity>balls_in_table[j].velocity:
                    fast=balls_in_table[i]
                    slow=balls_in_table[j]
                else :
                    fast=balls_in_table[j]
                    slow=balls_in_table[i]
                #print 'fast.angle : ',fast.number,"slow.angle: ",slow.number
                if slow.y-fast.y>0:
                    slow.angle=-(degrees(atan2((slow.y - fast.y ),
                                                       (slow.x- fast.x))))

                elif slow.y-fast.y<0:
                        slow.angle=-(degrees(atan2((slow.y - fast.y ),
                                                       (slow.x- fast.x))))

                
                if slow.angle<fast.angle: 
                    if fast.angle>270 and fast.angle<360 :
                        fast.angle=(slow.angle-90)
                        slow.velocity=fast.velocity/1.8+slow.velocity/2.0
                        fast.velocity=fast.velocity/2.0+slow.velocity/2.0+0.01
                    else : 
                        fast.angle=(slow.angle+90)
                        slow.velocity=fast.velocity/1.8+slow.velocity/2.0
                        fast.velocity=fast.velocity/2.0+slow.velocity/2.0+0.01
                if slow.angle>fast.angle :
                    fast.angle=slow.angle-90
                    slow.velocity=fast.velocity/1.8+slow.velocity/2.0
                    fast.velocity=fast.velocity/2.0+slow.velocity/2.0+0.01

                slow.change_position()
                fast.change_position()
    
#USED TO ADD TEXT TO BUTTONS AND END OF THE GAME              
def add_text(message,color,button_x,button_y,width,height,size=20):
    font=pygame.font.SysFont('Calibri',size) #general font
    textSurf = font.render(message,True,color)
    textRect= textSurf.get_rect()
    textRect.center = ((button_x+(width/2)), button_y+(height/2))
    screen.blit(textSurf, textRect)
#USED TO DEFINE THE FIRST SCREEN THAT APPEARS 
def intro_game():
    global screen #to blit

    start_of_game=True
    screen = pygame.display.set_mode((newgame.get_width(),newgame.get_height()),pygame.RESIZABLE) # Displays the mainscreen
    pygame.mouse.set_visible(1)
    while start_of_game:

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
        x,y=pygame.mouse.get_pos()
        screen.blit(newgame,(0,0))
        pygame.draw.rect(screen,[200,200,30],(175,100,130,50))# three buttons
        pygame.draw.rect(screen,[200,200,30],(375,100,130,50))
        pygame.draw.rect(screen,[200,200,30],(575,100,100,50))
        
        if x>175 and x<305:
            if y>100 and y<150:
                pygame.draw.rect(screen,[230,220,0],(175,100,130,50)) # changes the color when mouse goes over
                if pygame.mouse.get_pressed()[0]:
                    start_game()
        elif x>375 and x<505:
            if y>100 and y<150:
                pygame.draw.rect(screen,[230,220,0],(375,100,130,50))# changes the color when mouse goes over
                if pygame.mouse.get_pressed()[0]:
                    instructions_page()
        elif x>575 and x<675:
            if y>100 and y<150:               
                pygame.draw.rect(screen,[230,220,0],(575,100,100,50))# changes the color when mouse goes over
                if pygame.mouse.get_pressed()[0]:
                    pygame.quit()
                    sys.exit()
        add_text("New Game", [255,255,255], 175,100,130,50) # self explanatory
        add_text("Instructions", [255,255,255], 375,100,130,50)# self explanatory
        add_text("Quit",[255,255,255],575,100,100,50)# self explanatory


        pygame.display.update()
        clock.tick(15)


#THE PAGE WHERE THE INSTRUCTIONS IMAGE IS SHOWN
def instructions_page():
    instructions=True
    while instructions:
        for event in pygame.event.get():
            if event.type == pygame.QUIT: #to make possible the exit
                pygame.quit()
                sys.exit()
                
        x,y=pygame.mouse.get_pos()
        screen.blit(instructions_pic,(0,0))
        pygame.draw.rect(screen,[227,170,14],(400,400,100,50))
        add_text("Back", [255,255,255], 400,400,100,50,30)
        
        if x>400 and x<500 and y>400 and y<450:
            
            add_text("Back", [94,81,44], 400,400,100,50,30)
            #Back button
            if pygame.mouse.get_pressed()[0]:
                
                instructions=False
                
                intro_game()

        pygame.display.update()
        clock.tick(15)

                    
def result():   
    global solids_potted,stripes_potted,screen,eight
    
    if eight not in balls_in_table and len(balls_in_table)>0: # if the 8 ball is potted
            if len(solids_potted) ==7 or len(stripes_potted)==7: # if there is one finished list of balls then the current player won
                screen.fill([255,255,255])
                screen.blit(bg,(40,40))
                add_text("8 BALL POTTED ...",[255,255,255],365,100,200,200,60)
                add_text("YOU won :))) ",[255,255,255],365,200,200,200,60)

                if pygame.mouse.get_pressed()[0]:   # sends to main menu by mouse click
                        intro_game()

            else :
                
                screen.fill([255,255,255])  # otherwise the current player lost 
                screen.blit(bg,(40,40))
                add_text("8 BALL POTTED ...",[255,255,255],365,100,200,200,60)
                add_text("YOU lost :( ",[255,255,255],365,200,200,200,60)

                if pygame.mouse.get_pressed()[0]:

                        intro_game()
    



def restart_game():   # holds the balls

    global balls_in_table,two,eight # the list of all balls that are available
    balls_in_table=[] # starts the list

    # Defining the balls
    
    #69=balls(0,220,230,0,20)
    one=balls(1,678,275,0,12) # --
    ### second line ####
    three=balls(3,701,289,0,12)
    eleven=balls(11,701,265,0,12)
    ### third line ####
    fourteen=balls(14,724,250,0,12)
    eight=balls(8,724,275,0,12)
    six=balls(6,724,300,0,12)
    ########fourth line #########
    nine=balls(9,746,233,0,12)
    four=balls(4,746,289,0,12)
    fifteen=balls(15,746,265,0,12)
    five=balls(5,746,313,0,12)
    #########fifth line #########
    thirteen=balls(13,771,223,0,12)
    twelve=balls(12,771,250,0,12)
    ten=balls(10,771,275,0,12)
    two=balls(2,771,300,0,12)
    seven=balls(7,771,325,0,12)

    # appends the balls 
    balls_in_table.append(one)
    balls_in_table.append(two)
    balls_in_table.append(three)
    balls_in_table.append(four)
    balls_in_table.append(five)
    balls_in_table.append(six)
    balls_in_table.append(seven)
    balls_in_table.append(eight)
    balls_in_table.append(nine)
    balls_in_table.append(ten)
    balls_in_table.append(eleven)
    balls_in_table.append(twelve)
    balls_in_table.append(thirteen)
    balls_in_table.append(fourteen)
    balls_in_table.append(fifteen)
    
    global player1_balls,player2_balls,stripe_balls,solid_balls
    player1_balls=[]
    player2_balls=[]
    solid_balls=[one,two,three,four,five,six,seven] # used for later purpose
    stripe_balls=[nine,ten,eleven,twelve,thirteen,fourteen,fifteen] # used for later purpose
def start_game():
    global screen,player1_balls,player2_balls,solids,stripes,stripe_balls,solid_balls,player1,player2,white_ball,two,foul,player1,player2,stripes_potted,solids_potted,loop,eight
    screen = pygame.display.set_mode((bg.get_width()+80,
                                      bg.get_height()+80),
                                     ) # Displays the mainscreen
 
    phrase1='' # used to define what balls is the player about to hit
    phrase2='' # used to define what balls is the player about to hit
    solids_potted=[]
    stripes_potted=[]
    restart_game()
    pockets = [] #list of pockets
    solids=False
    stripes=False
    white_ball=balls(0,260,270,0,12)
    balls_in_table.append(white_ball)
    # defining pockets
    p1 = Pocket(84,84)
    p2 = Pocket(463,78)
    p3 = Pocket(860,84)
    p4 = Pocket(860,455)
    p5 = Pocket(465,465)
    p6 = Pocket(84,455)

    # appending pockets
    pockets.append(p1)
    pockets.append(p2)
    pockets.append(p3)
    pockets.append(p4)
    pockets.append(p5)
    pockets.append(p6)

    player1=True
    player2=False
    cueStick1=Cue(0,50,500,[0,0,0]) # Defines the stick
    cueStick2=Cue(0,50,500,[200,0,0])
    aim_beginning  = [] # needed to be used in the cue functions
    aim_end = []# needed to be used in the cue functions
    foul=False # no foul in the beginning
    type_of_ball_decided=False # stripes and solids have not been chosen yet
    for ball in balls_in_table:
        screen.blit(ball.show(), (ball.x, ball.y))  # shows all the balls        
        
    '''
    file='mainsound.ogg'
    pygame.init() 
    pygame.mixer.init()
    pygame.mixer.music.load(file)
        
    pygame.mixer.music.play()
    if not pygame.mixer.get_busy(): #keeps repeating the music whenever it stops
        file = 'mainsound.ogg'
        pygame.init()   
        pygame.mixer.init()
        pygame.mixer.music.load(file)
        pygame.mixer.music.play()'''
    pygame.mixer.init()
    pygame.mixer.Channel(1).play(pygame.mixer.Sound('mainsound.ogg'))
    loop=True
    while loop: #starting the main loop

        screen.fill([255,255,255])     # background fill   
        pygame.mouse.set_visible(0)# Makes mouse invisible
        screen.blit(bg, (40,40)) #shows the board
        result() #checks for result
        for ball in balls_in_table :
            ball.change_position()

        # used to show whose player turn it is
        if player1: 
            add_text('Player 1 turn !',[0,0,0],300,0,100,50,40) 
            if phrase1:
                add_text(' Pot ' + phrase2 + ' !',[0,0,0],550,0,100,50,40 )
        if player2:
            add_text('Player 2 turn !',[255,0,0],300,0,100,50,40 )
            if phrase2:
                add_text(' Pot ' + phrase1 + ' !',[0,0,0],550,0,100,50,40 )

            
        for potted_ball in solids_potted:
            
            potted_ball.x=57 +solids_potted.index(potted_ball)*35 # shows balls potted in the downside
            potted_ball.y=540
            potted_ball.radius=15
            potted_ball.velocity=0
            screen.blit(potted_ball.show(), (potted_ball.x, potted_ball.y))

            
        for potted_ball in stripes_potted:
            
            potted_ball.x=835 - stripes_potted.index(potted_ball)*35# shows balls potted in the downside
            potted_ball.y=540
            potted_ball.radius=15
            potted_ball.velocity=0
            potted_ball.show()
            screen.blit(potted_ball.show(), (potted_ball.x, potted_ball.y))

            
        counter=0 # used to get out of the if condition when the type of balls is selected
        if not type_of_ball_decided:
            if len(balls_in_table)==15:    
                if not player1:
                    if solids and not counter:
                        counter=1
                        player2_balls=solid_balls
                        player1_balls=stripe_balls
                        type_of_ball_decided=True
                        player1= True
                        player2= False
                        phrase2='solids'
                        phrase1='stripes'
                    if stripes and not counter:
                        counter=1
                        player2_balls=stripe_balls
                        player1_balls=solid_balls
                        type_of_ball_decided=True
                        player1= True
                        player2= False
                        phrase2='stripes'
                        phrase1='solids'

                if not player2:
                    if solids and not counter:
                        print'part3'
                        player1_balls=solid_balls
                        player2_balls=stripe_balls
                        type_of_ball_decided=True
                        player2= True
                        player1=  False
                        phrase2='stripes'
                        phrase1='solids'
                    if stripes and not counter:
                        print'part4'
                        player1_balls=stripe_balls
                        player2_balls=solid_balls
                        type_of_ball_decided=True
                        player2= True
                        player1= False
                        phrase2='solids'
                        phrase1='stripes'

        
        if foul :
            balls_in_table.remove(white_ball)
            x,y=pygame.mouse.get_pos()
            white_ball=balls(0,x,y,0,12)
            image=white_ball.show()
            screen.blit(image, (white_ball.x, white_ball.y))         

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    sys.exit()
                    quit()
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_q:
                        pygame.quit()
                        sys.exit()
                    if event.key == pygame.K_r:
                        start_game()
                if event.type==pygame.MOUSEBUTTONDOWN:
                    balls_in_table.append(white_ball)
        if white_ball not in balls_in_table :
            
            x,y=pygame.mouse.get_pos()
            white_ball=balls(0,x,y,0,12)
            image=white_ball.show()
            screen.blit(image, (white_ball.x, white_ball.y))
            for event in pygame.event.get():

                if event.type == pygame.QUIT:
                    sys.exit()
                    quit()
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_q:
                        pygame.quit()
                        sys.exit()
                    if event.key == pygame.K_r:
                        start_game()
                if event.type==pygame.MOUSEBUTTONDOWN:
                    balls_in_table.append(white_ball)

        if not (white_ball.velocity > 0):
            if player1:
                cueStick1.draw(white_ball.x+white_ball.radius, white_ball.y+white_ball.radius)
            if player2:
                cueStick2.draw(white_ball.x+white_ball.radius, white_ball.y+white_ball.radius)

        for i in range(6):
            pockets[i].ball_in_pocket()
        for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_q:
                        pygame.quit()
                        sys.exit()
                    if event.key == pygame.K_r:
                        start_game()
                if event.type == pygame.MOUSEBUTTONDOWN:
                    aim_beginning = [white_ball.x, white_ball.y]
                    x, y = pygame.mouse.get_pos()
                    aim_end = [x ,y]
                    dist = ((aim_beginning[0] - aim_end[0])**2 + (aim_beginning[1] - aim_end[1])**2)**0.5
                    force = dist/10.0
                    if force > 50:
                        force = 50
                    if player1:
                        cueStick1.aim_shoot(white_ball, force)
                    if player2:
                        cueStick2.aim_shoot(white_ball, force)
                    player1=not player1
                    player2=not player2
        collision_between_balls()

        pygame.display.update()
        clock.tick(40)


intro_game()
start_game()
